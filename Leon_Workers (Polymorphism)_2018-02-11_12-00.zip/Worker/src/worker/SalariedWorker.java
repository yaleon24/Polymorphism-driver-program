//package worker;





/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Yasmany
 */
public class SalariedWorker implements IWorkable{
   double yearly_salary;
   String empid; 

    public SalariedWorker(double yearly_salary, String empid) {
        this.yearly_salary = yearly_salary;
        this.empid = empid;
    }
   /*  public double computePay(double t){
        t=yearly_salary/52;
        return t=yearly_salary;
    }*/

    @Override
    public String toString() {
       String result = String.format("Salaried Worker: " + " employee id: "+empid+" weekly wages: " +"$%,.2f\n",yearly_salary/52);
      return result;
    }
   
    
}
