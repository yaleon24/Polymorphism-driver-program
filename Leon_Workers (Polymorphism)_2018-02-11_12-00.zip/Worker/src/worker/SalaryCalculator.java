//package worker;

//package
import java.util.Formatter;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
   
 */


import java.util.ArrayList;
import java.util.Scanner;

public class SalaryCalculator {
    public static void main(String[] args) {
        ArrayList<IWorkable> workers = new ArrayList<>();
        boolean toContinue = true;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Weekly salary calculator.");
        do{
            System.out.println("Enter an employee id:");
            String empId = scanner.next();
            System.out.println("Press 1 to add a new salaried worker.");
            System.out.println("Press 2 to add a new hourly worker.");
            while(!scanner.hasNextInt()){
                scanner.next();
            }
            int choice = scanner.nextInt();
            switch (choice){
                case (1):
                    System.out.println("Enter the employee's yearly salary:");
                    while(!scanner.hasNextDouble()){
                        scanner.next();
                    }
                    workers.add(new SalariedWorker(scanner.nextDouble(), empId));
                    break;
                case (2):
                    System.out.println("Enter the employee's hourly wages for the week:");
                    while(!scanner.hasNextDouble()){
                        scanner.next();
                    }
                    double hwages = scanner.nextDouble();
                    System.out.println("Enter the employee's hours worked for the week:");
                    while(!scanner.hasNextDouble()){
                        scanner.next();
                    }
                    double hworked = scanner.nextDouble();
                    workers.add(new HourlyWorker(empId, hwages, hworked));
                    break;
            }
            System.out.println("Do you wish to continue entering employees?");
            while(!scanner.hasNextBoolean()){
            scanner.next();
            }
            toContinue = scanner.nextBoolean();
        }while(toContinue);
        for (IWorkable worker : workers) {
            System.out.println(worker.toString());
        }
    }
    
}
