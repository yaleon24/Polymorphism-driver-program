//package worker;





/*
This is an individual assignment.  Your code CANNOT match anyone else's code.
 */




/**
 *
 * @author Yasmany
 */
public class HourlyWorker implements IWorkable{

String empid;    
double hourly_salary;
double hours;

    public HourlyWorker(String empid, double hourly_salary, double hours) {
        this.empid = empid;
        this.hourly_salary = hourly_salary;
        this.hours = hours;
    }

   /* public double computePay(double t){
        t=;
        return t=hourly_salary;
    }*/
    //"$%,2f\n"
    @Override
    public String toString() {
        String result= String.format( "Hourly Worker:  " + "employee id: " + empid + " weekly wages: " +"$%,.2f",hours*hourly_salary);
        return result;
    };


}
